package com.lucky_gr8.recordkeeper;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.LinkedList;

public class Student_ViewFragment extends Fragment {

    private static final String TAG = "Student_ViewFragmentlog";
    private LinkedList<Object> records;
    private RecyclerView recycleV;
    private DB_configrator db_configrator;
    private View view;
    private RecyclerAdapter_student recycleradapter;

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if(isVisibleToUser)
        {
            Log.d(TAG, "onResume: called");
            db_configrator = new DB_configrator(getContext());
            records = db_configrator.select_all(1);

            if (records != null) {
                Log.d(TAG, "onCreate: records were recieved");
                for (int i = 0; i < records.size(); i++) {
                    Student_DTO rec = (Student_DTO) records.get(i);
                    Log.d(TAG, "onCreate: " + rec.toString());
                }
                recycleV.setAdapter(new RecyclerAdapter_student(getActivity(),records,view));
                db_configrator.close_db();
            } else
                Log.d(TAG, "onCreate: records were not recieved");
        }
    }


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.student_view_fragment, container, false);
        this.view=view;
        recycleV = view.findViewById(R.id.Recycler_student);
        recycleV.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        Log.d(TAG, "onCreateView: this was called");


        db_configrator = new DB_configrator(getContext());

        boolean result = db_configrator.create_table(1);

        if (result) {
            records = db_configrator.select_all(1);
            if (records != null) {
                Log.d(TAG, "onCreate: records were recieved");
                for (int i = 0; i < records.size(); i++) {
                    Student_DTO rec = (Student_DTO) records.get(i);
                    Log.d(TAG, "onCreate: " + rec.toString());
                }
                recycleradapter = new RecyclerAdapter_student(getActivity(),records,view);
                recycleV.setAdapter(recycleradapter);
                db_configrator.close_db();
            } else
                Log.d(TAG, "onCreate: records were not recieved");
        } else
            Log.d(TAG, "onCreate: table was not created");

        return view;
    }
}
