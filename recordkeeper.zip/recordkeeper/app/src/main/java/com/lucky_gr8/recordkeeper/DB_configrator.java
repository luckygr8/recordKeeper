package com.lucky_gr8.recordkeeper;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.LinkedList;

public class DB_configrator {
    private static final String TAG = "DB_configratorlog";
    public SQLiteDatabase db;
    private String query;

    public DB_configrator(Context context) {
        db = context.openOrCreateDatabase(Queries.DB_NAME, Context.MODE_PRIVATE, null);
        db.setForeignKeyConstraintsEnabled(true);
    }

    public boolean create_table(int option_number) {
        switch (option_number) {
            case 1:
                try {
                    db.execSQL(Queries.CREATE_STUDENT_TABLE);
                } catch (Exception e) {
                    return false;
                }
                return true;
            case 2:
                try {
                    db.execSQL(Queries.CREATE_TABLE_GROUPINFO);
                }catch (Exception e){
                    return false;
                }
                return true;
            case 3:
                try {
                    db.execSQL(Queries.CREATE_COURSE_TABLE);
                } catch (Exception e) {
                    return false;
                }
                return true;
            case 4:
                try{
                    db.execSQL(Queries.CREATE_TABLE_GROUPMEMBER);
                }catch (Exception e){
                    return false;
                }
                return true;
            default:
                return false;
        }
    }

    public Object select_one(int id , int option_number){
        switch (option_number){
            case 2:
                try{
                    query = Queries.SELECT_ONE;
                    query+=Integer.toString(id);
                    Cursor c = db.rawQuery(query,null);

                    int groupid = c.getColumnIndex("groupid");
                    int groupname = c.getColumnIndex("groupname");
                    int groupdescription = c.getColumnIndex("groupdescription");
                    int courseid = c.getColumnIndex("courseid");
                    int isactive = c.getColumnIndex("isactive");
                    int startdate=c.getColumnIndex("startdate");

                    c.moveToFirst();
                    Log.d(TAG, "select_one: "+query);
                    return new Groupinfo_DTO(c.getString(groupname),c.getString(groupdescription),c.getInt(groupid),c.getLong(startdate),c.getInt(courseid),c.getInt(isactive));

                }catch (Exception e){
                    return null;
                }
                default: return null;
        }
    }

    public boolean insert_into_table(Object obj, int option_number) {
        switch (option_number) {
            case 1:
                try {
                    Student_DTO record = (Student_DTO) obj;
                    query = Queries.INSERT_INTO_STUDENT;
                    query += record.getStudentname() + "','" + record.getStudentphone() + "'," + record.getCourseid() + "," + record.getIsactive() + ")";

                    Log.d(TAG, "insert_into_table: " + query);
                    db.execSQL(query);
                } catch (Exception e) {
                    return false;
                }
                return true;
            case 2:
                try
                {
                    Groupinfo_DTO record = (Groupinfo_DTO) obj;
                    query = Queries.INSERT_INTO_GROUPINFO;
                    query += record.getGroupname() + "','" + record.getGroupdescription() + "'," + record.getCourseid() + "," + record.getIsactive() + ")";

                    Log.d(TAG, "insert_into_table: " + query);
                    db.execSQL(query);

                }catch (Exception e){
                    return false;
                }
                return true;
            case 3:
                try {
                    Course_DTO record = (Course_DTO) obj;
                    query = Queries.INSERT_INTO_COURSE;
                    query += record.getCoursename() + "')";

                    db.execSQL(query);

                } catch (Exception e) {
                    return false;
                }
                return true;
            case 4:
                try {
                    GroupMember_DTO record = (GroupMember_DTO) obj;
                    query = Queries.INSERT_INTO_GROUPMEMBER;
                    query += record.getGroupid()+","+record.getStudentid()+")";

                    Log.d(TAG, "insert_into_table: " + query);
                    db.execSQL(query);
                } catch (Exception e) {
                    return false;
                }
                return true;
            default:
                return false;
        }
    }

    public boolean update_into_database(Object obj, int option_number) {
        switch (option_number) {
            case 1:
                try {


                    Student_DTO record  = (Student_DTO) obj;
                    Log.d(TAG, "update_into_database: "+record.toString());
                    query=Queries.UPDATE_STUDENT;
                    query+="studentname = '"+record.getStudentname()+"',studentphone = '"+record.getStudentphone()+"',courseid = "+record.getCourseid()+",isactive = "+record.getIsactive()+" WHERE studentid = "+record.getStudentid();
                    Log.d(TAG, "update_into_database: "+query);

                    db.execSQL(query);
                } catch (Exception e) {
                    return false;
                }
                return true;
            default:
                return false;
        }
    }

    public LinkedList<Object> select_all(int option_number) {
        LinkedList<Object> records = new LinkedList<>();
        Cursor c;
        int count;
        switch (option_number) {
            case 1: {
                c = db.rawQuery(Queries.SELECT_STAR_FROM_STUDENT, null);

                int studentid = c.getColumnIndex("studentid");
                int studentname = c.getColumnIndex("studentname");
                int studentphone = c.getColumnIndex("studentphone");
                int courseid = c.getColumnIndex("courseid");
                int isactive = c.getColumnIndex("isactive");

                c.moveToFirst();

                if (c.getCount() == 0) {
                    Log.d(TAG, "select_from_table_student: records are not present");
                    return null;
                }

                count = 0;
                while (c != null) {
                    Log.d(TAG, "select_from_table: " + c.getInt(studentid));
                    Log.d(TAG, "select_from_table: " + c.getString(studentname));
                    Log.d(TAG, "select_from_table: " + c.getString(studentphone));
                    Log.d(TAG, "select_from_table: " + c.getInt(courseid));
                    Log.d(TAG, "select_from_table: " + c.getInt(isactive));
                    Log.d(TAG, "===================================================");

                    records.add(new Student_DTO(c.getInt(studentid), c.getString(studentname), c.getString(studentphone), c.getInt(courseid), c.getInt(isactive)));

                    c.moveToNext();
                    count++;
                    if (count == c.getCount())
                        break;
                }
                Log.d(TAG, "select_from_table: returning from viewall \n\n\n\n");
                return records;
            }
            case 2:

            {c = db.rawQuery(Queries.SELECT_STAR_FROM_GROUPINFO, null);

                int groupid = c.getColumnIndex("groupid");
                int groupname = c.getColumnIndex("groupname");
                int groupdescription = c.getColumnIndex("groupdescription");
                int courseid = c.getColumnIndex("courseid");
                int isactive = c.getColumnIndex("isactive");
                int startdate=c.getColumnIndex("startdate");

                c.moveToFirst();

                if (c.getCount() == 0) {
                    Log.d(TAG, "select_from_table_student: records are not present");
                    return null;
                }

                count = 0;
                while (c != null) {
                    Log.d(TAG, "select_from_table: " + c.getInt(groupid));
                    Log.d(TAG, "select_from_table: " + c.getString(groupname));
                    Log.d(TAG, "select_from_table: " + c.getString(groupdescription));
                    Log.d(TAG, "select_from_table: " + c.getInt(courseid));
                    Log.d(TAG, "select_from_table: " + c.getInt(isactive));
                    Log.d(TAG, "select from table: " + c.getLong(startdate));
                    Log.d(TAG, "===================================================");

                    records.add(new Groupinfo_DTO(c.getString(groupname),c.getString(groupdescription),c.getInt(groupid),c.getLong(startdate),c.getInt(courseid),c.getInt(isactive)));

                    c.moveToNext();
                    count++;
                    if (count == c.getCount())
                        break;
                }}
                Log.d(TAG, "select_from_table: returning from viewall \n\n\n\n");
                return records;
            case 3:
            {c = db.rawQuery(Queries.SELECT_STAR, null);

                int coursenameindex = c.getColumnIndex("coursename");
                int courseidindex = c.getColumnIndex("courseid");
                c.moveToFirst();

                if (c.getCount() == 0) {
                    Log.d(TAG, "select_from_table: records are not present");
                    return null;
                }

                count = 0;
                while (c != null) {
                    Log.d(TAG, "select_from_table: " + c.getString(coursenameindex));
                    Log.d(TAG, "select_from_table: " + c.getInt(courseidindex));
                    Log.d(TAG, "===================================================");

                    records.add(new Course_DTO(c.getString(coursenameindex), c.getInt(courseidindex)));

                    c.moveToNext();
                    count++;
                    if (count == c.getCount())
                        break;
                }}
                Log.d(TAG, "select_from_table: returning from viewall \n\n\n\n");
                return records;

            case 4:


            default:
                return null;
        }

    }

    public boolean delete_from_database(Object obj, int option_number) {
        switch (option_number) {
            case 1:
                try {
                    Student_DTO rec = (Student_DTO) obj;
                    query = Queries.DELETE_FROM_STUDNET;
                    query += " studentid = " + rec.getStudentid();

                    Log.d(TAG, "delete_from_database: "+query);
                    db.execSQL(query);
                } catch (Exception e) {
                    return false;
                }
                return true;
            case 2:
                try {
                    Groupinfo_DTO rec = (Groupinfo_DTO) obj;
                    query = Queries.DELETE_FROM_GROUP;
                    query += " groupid = " + rec.getGroupid();
                    db.execSQL(query);
                } catch (Exception e) {
                    return false;
                }
                return true;
            case 3:
                try {
                    Course_DTO rec = (Course_DTO) obj;
                    query = Queries.DELETE_FROM;
                    query += " courseid = " + rec.getCourseid();

                    Log.d(TAG, "delete_from_database: "+query);
                    db.execSQL(query);
                } catch (Exception e) {
                    return false;
                }
                return true;
            case 4:
                try{
                    GroupMember_DTO rec = (GroupMember_DTO) obj;
                    query=Queries.DELETE_FROM_GROUPMEMBER;
                    query+=rec.getGroupid()+" and studentid = "+rec.getStudentid();
                    Log.d(TAG, "delete_from_database: "+query);
                    db.execSQL(query);
                }catch (Exception e){
                    return false;
                }
                return true;
            default:
                return false;
        }

    }

    public LinkedList<Object> select_all_from_groupmember(int groupid){
        LinkedList<Object> records = new LinkedList<>();
        Cursor c;
        int count;
        query=Queries.SELECT_RECORDS_FROM_GROUPMEMBER;
        query+=groupid;
        Log.d(TAG, "select_all_from_groupmember: "+query);
        c = db.rawQuery(query, null);

        int studentname = c.getColumnIndex("studentname");
        int isactive = c.getColumnIndex("isactive");
        int studentid=c.getColumnIndex("studentid");
        int groupindex = c.getColumnIndex("groupid");
        c.moveToFirst();

        if (c.getCount() == 0) {
            Log.d(TAG, "select_from_table_student: records are not present");
            return null;
        }

        count = 0;
        while (c != null && c.getCount()>0) {
            Log.d(TAG, "select_from_table: " + c.getInt(groupindex));
            Log.d(TAG, "select_from_table: " + c.getString(studentname));
            Log.d(TAG, "select_from_table: " + c.getInt(studentid));
            Log.d(TAG, "select_from_table: " + c.getInt(isactive));
            Log.d(TAG, "===================================================");

            records.add(new GroupMember_DTO(c.getInt(groupindex),c.getInt(studentid),c.getString(studentname),c.getInt(isactive)));
            c.moveToNext();
            count++;
            if (count == c.getCount())
                break;
        }
        Log.d(TAG, "select_from_table: returning from viewall \n\n\n\n");
        return records;
    }

    public String select_phonenumber(int studentid)
    {
        String phonenumber;
        Cursor c;

        query=Queries.SELECT_PHONE_NUMBER;
        query+=studentid;
        Log.d(TAG, "select studentphone: "+query);
        c = db.rawQuery(query, null);

        int studentphone = c.getColumnIndex("studentphone");
        c.moveToFirst();
        Log.d(TAG, "select_phonenumber: "+c.getCount());
        if (c.getCount() == 0) {
            Log.d(TAG, "select_from_table_student: records are not present");
            return null;
        }

        phonenumber = c.getString(studentphone);
        Log.d(TAG, "select_phonenumber: "+phonenumber);

        Log.d(TAG, "select_from_table: returning from viewall \n\n\n\n");
        return phonenumber;

    }

    public String select_coursename(int courseid)
    {
        String studentcourse;
        Cursor c;

        query=Queries.SELECT_COURSE_NAME;
        query+=courseid;
        Log.d(TAG, "select coursename: "+query);
        c = db.rawQuery(query, null);

        int coursename = c.getColumnIndex("coursename");
        c.moveToFirst();
        Log.d(TAG, "select_coursename: "+c.getCount());
        if (c.getCount() == 0) {
            Log.d(TAG, "select_from_table_student: records are not present");
            return null;
        }

        studentcourse = c.getString(coursename);
        Log.d(TAG, "select coursename: "+studentcourse);

        Log.d(TAG, "select_from_table: returning from viewall \n\n\n\n");
        return studentcourse;

    }

    public void close_db() {
        db.close();
    }

    /**
     * development only methods , do not use
     */

    @Deprecated
    public void execute_custom_sql(String query){
            db.execSQL(query);

    }

    @Deprecated
    public boolean drop_table(String tbname) {
        try {
            query = Queries.DROP_TABLE;
            query += tbname;
            db.execSQL(query);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

}
