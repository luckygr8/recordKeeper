package com.lucky_gr8.recordkeeper;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import java.util.LinkedList;
import java.util.List;

public class Course_operations extends AppCompatActivity {
    private static final String TAG = "Course_operationslog";
    private ViewPager mViewPager;
    private SectionStatePagerAdapter mSectionStatePagerAdapter_forGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_operations);

        mSectionStatePagerAdapter_forGroup = new SectionStatePagerAdapter(getSupportFragmentManager());
        mViewPager = findViewById(R.id.Course_activity);
        Init(mViewPager);

    }

    private void Init(ViewPager viewPager) {
        SectionStatePagerAdapter adapter = new SectionStatePagerAdapter(getSupportFragmentManager());

        adapter.addFragment(new Course_AddFragment(), "add fragment");
        adapter.addFragment(new Course_ViewFragment(), "view fragment");
        viewPager.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed: ");
        finish();
        Intent openMainActivity = new Intent(this, MainActivity.class);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openMainActivity, 0);
    }

    public void add_course(View view) {
        TextInputEditText textInputEditText = findViewById(R.id.TextField_coursename);
        String coursename = textInputEditText.getEditableText().toString().trim();
        TextInputLayout til = (TextInputLayout) findViewById(R.id.TextInputLayout_coursename);
        if (coursename.isEmpty()) {
            Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(300);
            }
            til.setError("You need to enter a name");
            return;
        }
        View parentLayout = findViewById(android.R.id.content);

        DB_configrator db_configrator = new DB_configrator(this);
        boolean result = db_configrator.create_table(3);
        if (result) {
            result = db_configrator.insert_into_table(new Course_DTO(coursename), 3);
            if (result) {
                Log.d(TAG, "onCreate: record was added");
                Snackbar.make(parentLayout, "the course was added", Snackbar.LENGTH_LONG)
                        .setAction("CLOSE", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                            }
                        })
                        .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                        .show();

                textInputEditText.setText("");
                til.setError(null);
            } else {
                Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(300);
                }
                Snackbar.make(parentLayout, "looks like that name already exists", Snackbar.LENGTH_INDEFINITE)
                        .setAction("CLOSE", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                            }
                        })
                        .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                        .show();
            }
        } else {
            Log.d(TAG, "onCreate: table was not created");
        }
        db_configrator.close_db();
    }
}
