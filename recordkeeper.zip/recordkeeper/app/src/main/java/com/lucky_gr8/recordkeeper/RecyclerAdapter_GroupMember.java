package com.lucky_gr8.recordkeeper;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class RecyclerAdapter_GroupMember extends RecyclerView.Adapter<RecyclerAdapter_GroupMember.viewholder> {

    private Context context;
    private LinkedList<Object> all_records;
    private GroupMember_DTO curr_rec = new GroupMember_DTO();
    private static final String TAG = "RecyclerAdapter_GroupMelog";
    private int itemposition;
    private LinkedList<RecyclerAdapter_GroupMember.viewholder> selected_views = new LinkedList<>();
    private int selected_item_count = 0;

    public RecyclerAdapter_GroupMember(final Context context, LinkedList<Object> all_records , View fab_sms_button) {
        this.context = context;
        this.all_records = all_records;

        fab_sms_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(context, "selected students : "+selected_item_count, Toast.LENGTH_SHORT).show();
                Dialog smsdialog  = new Dialog(context);
                smsdialog.setContentView(R.layout.send_message_popup);

                final TextInputEditText textInputEditText = smsdialog.findViewById(R.id.txt_messagetext);

                smsdialog.findViewById(R.id.popup_confirm_button).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(selected_views.size()>0)
                        {
                            boolean valid=true;
                            String message = textInputEditText.getText().toString().trim();
                            if(message.isEmpty())valid=false;

                            if(valid){
                                int permission = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS);
                                if(permission==PackageManager.PERMISSION_GRANTED){

                                    for(int i=0;i<selected_views.size();i++){

                                        String phonenumber="";
                                        viewholder vi = selected_views.get(i);
                                        GroupMember_DTO rec = vi.rec;
                                        DB_configrator db_configrator = new DB_configrator(context);
                                        phonenumber = db_configrator.select_phonenumber(rec.getStudentid());

                                        Log.d(TAG, "onClick: "+phonenumber);
                                        try{
                                            SmsManager smsManager = SmsManager.getDefault();
                                            smsManager.sendTextMessage(phonenumber,null,message,null,null);
                                            valid=true;
                                        }catch (Exception e){
                                            Toast.makeText(context, "could not send message", Toast.LENGTH_SHORT).show();
                                            valid=false;
                                        }
                                        db_configrator.close_db();
                                    }
                                    if(valid)
                                        Toast.makeText(context, "message was send to "+selected_item_count+" students", Toast.LENGTH_SHORT).show();

                                }else{
                                    ActivityCompat.requestPermissions((Activity) context,new String[]{Manifest.permission.SEND_SMS},0);
                                }
                            }
                        }else{
                            Toast.makeText(context, "you need to select students for this", Toast.LENGTH_LONG).show();
                            Vibrator vibrator = (Vibrator) context.getSystemService(context.VIBRATOR_SERVICE);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                            } else {
                                vibrator.vibrate(300);
                            }
                        }
                    }
                });


                smsdialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                smsdialog.show();
            }
        });
    }

    public void showsnackbar(View view) {
        if (selected_item_count == 0) {
            Snackbar.make(view, "no record selected", Snackbar.LENGTH_LONG)
                    .setAction("CLOSE", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    })
                    .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                    .show();
        } else {

            Snackbar.make(view, "selected records : " + selected_item_count, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.delete_string, new View.OnClickListener() {

                        @Override
                        public void onClick(final View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            builder.setMessage(selected_item_count+" record(s) will be permanently deleted ")
                                    .setCancelable(false)
                                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            int total = selected_views.size();
                                            DB_configrator db_configrator = new DB_configrator(context);
                                            boolean result = db_configrator.create_table(4);
                                            RecyclerAdapter_GroupMember.viewholder viewholder;
                                            if (result) {
                                                for (int i = 0; i < total; i++) {
                                                    viewholder = selected_views.get(i);
                                                    curr_rec = viewholder.rec;
                                                    Log.d(TAG, "onClick: " + curr_rec.toString());
                                                    result = db_configrator.delete_from_database(curr_rec, 4);
                                                    if (result) {
                                                        Log.d(TAG, "onClick: record with id :: " + curr_rec.getStudentid() + " groupid " + curr_rec.getGroupid() + " was deleted");
                                                        all_records.remove(curr_rec);
                                                        notifyItemRemoved(viewholder.corresponding_item_psition);

                                                    } else
                                                        Log.d(TAG, "onClick: delete failure");
                                                }
                                            }
                                            db_configrator.close_db();
                                        }
                                    })
                                    .setNeutralButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                        }
                                    });
                            AlertDialog alert = builder.create();

                            alert.setTitle("group member operations");

                            alert.show();
                        }
                    })
                    .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = LayoutInflater.from(viewGroup.getContext());
        View v = li.inflate(R.layout.groupmember_recycler_item, viewGroup, false);
        return new RecyclerAdapter_GroupMember.viewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final viewholder viewholder, int i) {
        curr_rec = (GroupMember_DTO) all_records.get(i);
        viewholder.groupmember_item_textV_name.setText(curr_rec.getStudentename());
        
        if(curr_rec.getIsactive()==1)
            viewholder.groupmember_item_textV_information.setText(" active ");
        else
            viewholder.groupmember_item_textV_information.setText(" in-active ");
        
        viewholder.rec.setGroupid(curr_rec.getGroupid());
        viewholder.rec.setStudentename(curr_rec.getStudentename());
        viewholder.rec.setStudentid(curr_rec.getStudentid());
        viewholder.rec.setIsactive(curr_rec.getIsactive());

        Log.d(TAG, "onBindViewHolder: " + viewholder.rec.toString());


        viewholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (selected_item_count == 0 && !viewholder.is_selected) {
                    selected_item_count++;
                    viewholder.is_selected = true;
                    viewholder.groupmember_item_select.setVisibility(View.VISIBLE);
                    selected_views.add(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                    v.setBackgroundColor(backgroundColor);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar(viewholder.itemView);

                }
                return true;
            }
        });
        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selected_item_count > 0 && !viewholder.is_selected) {
                    viewholder.is_selected = true;
                    selected_item_count++;
                    viewholder.groupmember_item_select.setVisibility(View.VISIBLE);
                    selected_views.add(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                    v.setBackgroundColor(backgroundColor);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar(viewholder.itemView);

                    return;
                }
                if (viewholder.is_selected) {
                    selected_item_count--;
                    viewholder.is_selected = false;
                    selected_views.remove(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.default_color);
                    v.setBackgroundColor(backgroundColor);
                    viewholder.groupmember_item_select.setVisibility(View.INVISIBLE);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar(viewholder.itemView);

                    return;
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return all_records.size();
    }

    public class viewholder extends RecyclerView.ViewHolder{
        TextView groupmember_item_textV_name,groupmember_item_textV_information;
        ImageView groupmember_item_select;
        boolean is_selected;
        GroupMember_DTO rec;
        int corresponding_item_psition;

        @Override
        public boolean equals( Object obj) {
            return super.equals(obj);
        }

        public viewholder(@NonNull View itemView) {
            super(itemView);
            is_selected=false;
            groupmember_item_textV_name = itemView.findViewById(R.id.groupmember_item_textV_name);
            groupmember_item_textV_information = itemView.findViewById(R.id.groupmember_item_textV_information);
            groupmember_item_select = itemView.findViewById(R.id.groupmember_item_select);
            corresponding_item_psition=0;
            rec = new GroupMember_DTO();
        }
    }
}
