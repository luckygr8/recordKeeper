package com.lucky_gr8.recordkeeper;

import java.util.Objects;

public class Student_DTO {
    private int studentid;
    private String studentname;
    private String studentphone;
    private int courseid;
    private int isactive;

    public Student_DTO(String studentname, String studentphone, int courseid, int isactive) {
        this.studentname = studentname;
        this.studentphone = studentphone;
        this.courseid = courseid;
        this.isactive = isactive;
    }
    public Student_DTO(int studentid ,String studentname, String studentphone, int courseid, int isactive) {
        this.studentname = studentname;
        this.studentphone = studentphone;
        this.courseid = courseid;
        this.isactive = isactive;
        this.studentid=studentid;
    }
    public int getStudentid() {
        return studentid;
    }

    public void setStudentid(int studentid) {
        this.studentid = studentid;
    }

    public String getStudentname() {
        return studentname;
    }

    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }

    public String getStudentphone() {
        return studentphone;
    }

    public void setStudentphone(String studentphone) {
        this.studentphone = studentphone;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public int getIsactive() {
        return isactive;
    }

    public void setIsactive(int isactive) {
        this.isactive = isactive;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student_DTO that = (Student_DTO) o;
        return studentid == that.studentid &&
                courseid == that.courseid &&
                isactive == that.isactive &&
                Objects.equals(studentname, that.studentname) &&
                Objects.equals(studentphone, that.studentphone);
    }

    @Override
    public int hashCode() {
        return Objects.hash(studentid, studentname, studentphone, courseid, isactive);
    }

    @Override
    public String toString() {
        return "Student_DTO{" +
                "studentid=" + studentid +
                ", studentname='" + studentname + '\'' +
                ", studentphone='" + studentphone + '\'' +
                ", courseid=" + courseid +
                ", isactive=" + isactive +
                '}';
    }

    public Student_DTO() {
    }
}
