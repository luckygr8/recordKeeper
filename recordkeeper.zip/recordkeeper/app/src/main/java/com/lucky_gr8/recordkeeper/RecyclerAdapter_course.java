package com.lucky_gr8.recordkeeper;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class RecyclerAdapter_course extends RecyclerView.Adapter<RecyclerAdapter_course.Viewholder> {

    private Context context;
    private LinkedList<Object> all_records;
    private Course_DTO curr_rec = new Course_DTO(" ");
    private int itemposition;
    private static final String TAG = "RecyclerAdapter_courselog";

    public RecyclerAdapter_course(LinkedList<Object> all_records , Context context) {
        this.all_records = all_records;
        this.context=context;
    }


    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = LayoutInflater.from(viewGroup.getContext());
        View v =li.inflate(R.layout.recycler_course_item,viewGroup,false);
        return new Viewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder viewholder, int i) {
        curr_rec = (Course_DTO) all_records.get(i);
        String str = curr_rec.getCoursename()+"\n ";
        viewholder.course_item_textV.setText(str);
        viewholder.rec.setCoursename(curr_rec.getCoursename());
        viewholder.rec.setCourseid(curr_rec.getCourseid());


        viewholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                viewholder.is_selected=true;
                itemposition = viewholder.getAdapterPosition();
                viewholder.corresponding_item_position=itemposition;
                int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                viewholder.course_item_delete.setVisibility(View.VISIBLE);
              //  viewholder.course_item_update.setVisibility(View.VISIBLE);
                v.setBackgroundColor(backgroundColor);
                return true;
            }
        });

        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(viewholder.is_selected){
                    int backgroundColor = ContextCompat.getColor(context, R.color.default_color);
                    viewholder.course_item_delete.setVisibility(View.INVISIBLE);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_position=itemposition;
                 //   viewholder.course_item_update.setVisibility(View.INVISIBLE);
                    viewholder.is_selected=false;
                    v.setBackgroundColor(backgroundColor);
                }
            }
        });

        viewholder.course_item_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DB_configrator db_configrator = new DB_configrator(context);
                Course_DTO rec = new Course_DTO(viewholder.rec.getCoursename(),viewholder.rec.getCourseid());
                boolean result = db_configrator.delete_from_database(rec,3);
                if(result){
                    Toast.makeText(context, "deleted", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "onClick: deleted"+rec.toString());
                    all_records.remove(rec);
                    notifyItemRemoved(viewholder.corresponding_item_position);
                }
                else
                {
                    Log.d(TAG, "onClick: not deleted");
                    Toast.makeText(context, "could not delete", Toast.LENGTH_SHORT).show();
                }
            }

        });

    }

    @Override
    public int getItemCount() {
        return all_records.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder{

        TextView course_item_textV;
        Course_DTO rec;
        boolean is_selected;
        //ImageView course_item_update;
        ImageView course_item_delete;
        int corresponding_item_position;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            rec= new Course_DTO(" ");
            is_selected=false;
            course_item_textV = itemView.findViewById(R.id.course_item_textV);
            course_item_delete = itemView.findViewById(R.id.course_item_delete);
           // course_item_update = itemView.findViewById(R.id.course_item_update);
            corresponding_item_position=0;
        }
    }

}
