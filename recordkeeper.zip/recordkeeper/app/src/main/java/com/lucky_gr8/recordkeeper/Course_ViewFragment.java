package com.lucky_gr8.recordkeeper;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import java.util.LinkedList;

public class Course_ViewFragment extends Fragment {
    private static final String TAG = "Course_ViewFragmentlog";
    private LinkedList<Object> records = null;
    private RecyclerView recycleV;
    private DB_configrator db_configrator;
    private RecyclerAdapter_course recycleradapter;

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if(isVisibleToUser)
        {
            Log.d(TAG, "onResume: called");
            db_configrator = new DB_configrator(getContext());
            records = db_configrator.select_all(3);

            if (records != null) {
                Log.d(TAG, "onCreate: records were recieved");
                for (int i = 0; i < records.size(); i++) {
                    Course_DTO rec = (Course_DTO) records.get(i);
                    Log.d(TAG, "onCreate: " + rec.toString());
                }
                recycleV.setAdapter(new RecyclerAdapter_course(records, getActivity()));
                db_configrator.close_db();
            } else
                Log.d(TAG, "onCreate: records were not recieved");
        }
    }


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.course_view_fragment, container, false);
        recycleV = view.findViewById(R.id.Recycler_course);
        recycleV.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        Log.d(TAG, "onCreateView: this was called");


        db_configrator = new DB_configrator(getContext());

        boolean result = db_configrator.create_table(3);

        if (result) {
            records = db_configrator.select_all(3);
            if (records != null) {
                Log.d(TAG, "onCreate: records were recieved");
                for (int i = 0; i < records.size(); i++) {
                    Course_DTO rec = (Course_DTO) records.get(i);
                    Log.d(TAG, "onCreate: " + rec.toString());
                }
                recycleradapter = new RecyclerAdapter_course(records, getActivity());
                recycleV.setAdapter(recycleradapter);
                db_configrator.close_db();
            } else
                Log.d(TAG, "onCreate: records were not recieved");
        } else
            Log.d(TAG, "onCreate: table was not created");

        return view;
    }
}
