package com.lucky_gr8.recordkeeper;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.LinkedList;

public class RecyclerAdapter_group extends RecyclerView.Adapter<RecyclerAdapter_group.Viewholder> {

    private static final String TAG = "RecyclerAdapter_grouplog";
    private Context context;
    private LinkedList<Object> all_records;
    private int itemposition;
    private Context popup_context;
    private LinkedList<RecyclerAdapter_group.Viewholder> selected_views = new LinkedList<>();
    private int selected_item_count = 0;
    private RecyclerAdapter_group.Viewholder view_to_be_updated = null;
    private Dialog dialog;

    private Groupinfo_DTO curr_rec = new Groupinfo_DTO();

    public RecyclerAdapter_group(Context context, LinkedList<Object> all_records , Context popup_context) {
        this.context = context;
        this.all_records = all_records;
        this.popup_context=popup_context;
    }

    public void showsnackbar(View view) {
        final View v = view;
        if (selected_item_count == 0) {
            Snackbar.make(view, "no group selected", Snackbar.LENGTH_LONG)
                    .setAction("CLOSE", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    })
                    .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                    .show();
        } else {

            Snackbar.make(view, "selected records : " + selected_item_count, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.delete_string, new View.OnClickListener() {

                        @Override
                        public void onClick(final View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(popup_context);
                            builder.setMessage(selected_item_count+" record(s) will be permanently deleted ")
                                    .setCancelable(false)
                                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            int total = selected_views.size();
                                            DB_configrator db_configrator = new DB_configrator(context);
                                            boolean result = db_configrator.create_table(2);
                                            RecyclerAdapter_group.Viewholder viewholder;
                                            if (result) {
                                                for (int i = 0; i < total; i++) {
                                                    viewholder = selected_views.get(i);
                                                    curr_rec = viewholder.rec;
                                                    Log.d(TAG, "onClick: currec tostring" + curr_rec.toString());
                                                    result = db_configrator.delete_from_database(curr_rec, 2);
                                                    if (result) {
                                                        Log.d(TAG, "onClick: record with id :: " + curr_rec.getGroupid() + " name:: " + curr_rec.getGroupname() + " was deleted");
                                                        all_records.remove(curr_rec);
                                                        notifyItemRemoved(viewholder.corresponding_item_psition);


                                                    } else{
                                                        Log.d(TAG, "onClick: delete failure");
                                                    Snackbar.make(v, "invalid selection : group is not empty", Snackbar.LENGTH_LONG)
                                                            .setAction("CLOSE", new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {

                                                                }
                                                            })
                                                            .setActionTextColor(v.getResources().getColor(android.R.color.holo_red_light))
                                                            .show();}
                                                }
                                            }
                                            db_configrator.close_db();
                                        }
                                    })
                                    .setNeutralButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                        }
                                    });
                            AlertDialog alert = builder.create();

                            alert.setTitle("student operations");

                            alert.show();
                        }
                    })
                    .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }
    }


    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = LayoutInflater.from(viewGroup.getContext());
        View v = li.inflate(R.layout.recycler_group_item, viewGroup, false);
        return new RecyclerAdapter_group.Viewholder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder viewholder, int i) {
        curr_rec = (Groupinfo_DTO) all_records.get(i);
        String str = curr_rec.getGroupname();
        viewholder.group_item_textV_name.setText(str);

        str=Long.toString(curr_rec.getStartdate());
        if(curr_rec.getIsactive()==1)
            str+=" || active";
        else
            str+=" || inactive";

        str+= "     ( "+curr_rec.getGroupdescription()+" )";

        viewholder.group_item_textV_information.setText(str);


        viewholder.rec.setGroupid(curr_rec.getGroupid());
        viewholder.rec.setGroupname(curr_rec.getGroupname());
        viewholder.rec.setCourseid(curr_rec.getCourseid());
        viewholder.rec.setGroupdescription(curr_rec.getGroupdescription());
        viewholder.rec.setIsactive(curr_rec.getIsactive());
        viewholder.rec.setStartdate(curr_rec.getStartdate());

        Log.d(TAG, "onBindViewHolder: " + viewholder.rec.toString());

        viewholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (selected_item_count == 0 && !viewholder.is_selected) {
                    selected_item_count++;
                    viewholder.is_selected = true;
                    viewholder.group_item_checked.setVisibility(View.VISIBLE);
                    selected_views.add(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                    v.setBackgroundColor(backgroundColor);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;
                    viewholder.group_item_update.setVisibility(View.VISIBLE);
                    view_to_be_updated = viewholder;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar(v);

                }
                return true;


            }
        });

        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selected_item_count > 0 && !viewholder.is_selected) {
                    viewholder.is_selected = true;
                    selected_item_count++;
                    viewholder.group_item_checked.setVisibility(View.VISIBLE);
                    selected_views.add(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                    v.setBackgroundColor(backgroundColor);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar(v);

                    return;
                }
                if (viewholder.is_selected) {
                    selected_item_count--;
                    viewholder.is_selected = false;
                    selected_views.remove(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.default_color);
                    v.setBackgroundColor(backgroundColor);
                    viewholder.group_item_checked.setVisibility(View.INVISIBLE);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;
                    viewholder.group_item_update.setVisibility(View.INVISIBLE);

                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar(v);

                    return;
                }

                if(selected_item_count==0 && !viewholder.is_selected){

                    Groupinfo_DTO rec = viewholder.rec;

                    Intent intent = new Intent(context,GroupMembers_Activity.class);
                    intent.putExtra("groupid",rec.getGroupid());
                    context.startActivity(intent);
                }
            }
        });


        viewholder.group_item_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selected_views.size() == 1) {

                    Log.d(TAG, "onClick: update :: " + viewholder.rec.toString());
                    //DB_configrator db_configrator = new DB_configrator(context);
                    //curr_rec = viewholder.rec;
                    //db_configrator.update_into_database(curr_rec,1);
                    curr_rec = viewholder.rec;
                    view_to_be_updated = viewholder;
                    //showpopup();

                } else
                    Snackbar.make(v, "can not update muptiple records", Snackbar.LENGTH_LONG)
                            .setAction("CLOSE", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                }
                            })
                            .setActionTextColor(v.getResources().getColor(android.R.color.holo_red_light))
                            .show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return all_records.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder{

        TextView group_item_textV_name;
        TextView group_item_textV_information;
        ImageView group_item_checked;
        ImageView group_item_update;
        boolean is_selected;
        Groupinfo_DTO rec;
        int corresponding_item_psition;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            is_selected = false;
            group_item_textV_name = itemView.findViewById(R.id.group_item_textV_name);
            group_item_textV_information = itemView.findViewById(R.id.group_item_textV_information);
            group_item_checked = itemView.findViewById(R.id.group_item_checked);
            group_item_update=itemView.findViewById(R.id.group_item_update);
            rec = new Groupinfo_DTO();
            corresponding_item_psition = 0;
        }
    }
}
