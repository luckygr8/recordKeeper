package com.lucky_gr8.recordkeeper;

import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class Student_operations extends AppCompatActivity {
    private static final String TAG = "Student_operationslog";
    static int count = 0;

    private ViewPager mViewPager;
    private SectionStatePagerAdapter mSectionStatePagerAdapter_forStudent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_operations);

        mSectionStatePagerAdapter_forStudent = new SectionStatePagerAdapter(getSupportFragmentManager());
        mViewPager = findViewById(R.id.Student_activity);
        Init(mViewPager);


    }

    private void Init(ViewPager viewPager) {
        SectionStatePagerAdapter adapter = new SectionStatePagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Student_AddFragment(), "add fragment");

        adapter.addFragment(new Student_ViewFragment(), "view fragment");
        viewPager.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed: ");
        finish();
        Intent openMainActivity = new Intent(this, MainActivity.class);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openMainActivity, 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: student operations was resumed");
    }

    public void add_student(View view) {
        TextInputEditText textInputEditText_name = findViewById(R.id.TextField_studentname);
        TextInputEditText textInputEditText_phone = findViewById(R.id.TextField_studentphone);
        Spinner spinner = findViewById(R.id.course_spinner);
        Course_DTO course = null;
        boolean valid = true;
        String studentname = textInputEditText_name.getEditableText().toString().trim();
        String studentphone = textInputEditText_phone.getEditableText().toString().trim();
        if (studentname.isEmpty() || studentphone.isEmpty())
            valid = false;
        if (spinner.getSelectedItemPosition() > 0) {
            course = (Course_DTO) spinner.getSelectedItem();
        } else valid = false;

        if (valid) {
            Student_DTO record = new Student_DTO(studentname, studentphone, course.getCourseid(), 1);
            Log.d(TAG, "add_student: " + record.toString());

            DB_configrator db_configrator = new DB_configrator(this);
            boolean result = db_configrator.create_table(1);
            if (result) {
                Log.d(TAG, "add_student: table created");
            } else Log.d(TAG, "add_student: table failed");

            result = db_configrator.insert_into_table(record, 1);
            if (result) {
                Log.d(TAG, "add_student: record added");

                Snackbar.make(view, "the record was successfully added", Snackbar.LENGTH_LONG)
                        .setAction("CLOSE", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                            }
                        })
                        .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                        .show();

                textInputEditText_name.setText("");
                textInputEditText_phone.setText("");
                spinner.setSelection(0);
            } else {
                Snackbar.make(view, "there was a problem entering the record", Snackbar.LENGTH_INDEFINITE)
                        .setAction("CLOSE", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                            }
                        })
                        .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                        .show();
            }

            db_configrator.close_db();

        } else {
            Vibrator v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(300);
            }
            Snackbar.make(view, "one or more inputs need to be filled", Snackbar.LENGTH_LONG)
                    .setAction("CLOSE", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    })
                    .setActionTextColor(getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }


    }
}

