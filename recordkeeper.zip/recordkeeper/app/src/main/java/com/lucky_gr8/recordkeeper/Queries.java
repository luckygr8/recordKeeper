package com.lucky_gr8.recordkeeper;


public interface Queries {

    // database name
    String DB_NAME = "RecordKeeper";



    // table names
    String course_table_name=" course";
    String student_table_name=" student ";
    String groupinfo_table_name=" groupinfo ";
    String group_member = " groupmember";



    // create table queries
    String CREATE_COURSE_TABLE = "CREATE TABLE IF NOT EXISTS"+course_table_name+" ( courseid INTEGER PRIMARY KEY AUTOINCREMENT , coursename TEXT UNIQUE )";
    String CREATE_STUDENT_TABLE = "CREATE TABLE IF NOT EXISTS"+student_table_name+" ( studentid INTEGER PRIMARY KEY AUTOINCREMENT , studentname TEXT , studentphone TEXT , courseid INTEGER , isactive INTEGER , FOREIGN KEY (courseid) REFERENCES"+course_table_name+"(courseid))";
    String CREATE_TABLE_GROUPINFO = "CREATE TABLE IF NOT EXISTS"+groupinfo_table_name+" ( groupid INTEGER PRIMARY KEY AUTOINCREMENT , groupname TEXT UNIQUE , groupdescription TEXT , startdate DATE DEFAULT CURRENT_DATE , courseid INTEGER , isactive INTEGER , FOREIGN KEY (courseid) REFERENCES"+course_table_name+"(courseid))";
    String CREATE_TABLE_GROUPMEMBER = "CREATE TABLE IF NOT EXISTS"+group_member+" ( groupid INTEGER , studentid INTEGER , PRIMARY KEY (groupid , studentid) ,FOREIGN KEY (groupid) REFERENCES"+groupinfo_table_name+"(groupid) , FOREIGN KEY (studentid) REFERENCES"+student_table_name+"(studentid))";

    //insertion queries

    //course
    String INSERT_INTO_COURSE = "INSERT INTO"+course_table_name+"(coursename) values('";

    //student
    String INSERT_INTO_STUDENT= "INSERT INTO"+student_table_name+"(studentname,studentphone,courseid,isactive) values('";

    //groupinfo
    String INSERT_INTO_GROUPINFO="INSERT INTO"+groupinfo_table_name+"(groupname,groupdescription,courseid,isactive) values('";

    //groupmember
    String INSERT_INTO_GROUPMEMBER="INSERT INTO"+group_member+" (groupid,studentid) values(";

    // selection queries

    //course
    String SELECT_STAR = "SELECT * FROM"+course_table_name;

    //student
    String SELECT_STAR_FROM_STUDENT="SELECT * FROM"+student_table_name;

    //groupinfo
    String SELECT_STAR_FROM_GROUPINFO="SELECT * FROM"+groupinfo_table_name;

    //groupmember
    String SELECT_RECORDS_FROM_GROUPMEMBER = "SELECT groupinfo.groupid,student.studentid,studentname,student.isactive from"+
            student_table_name+" join "+group_member+
            " on student.studentid = groupmember.studentid "+
            "join groupinfo on groupinfo.groupid = groupmember.groupid WHERE groupmember.groupid=";             //+groupinfo_table_name+" WHERE student.studentid = studentid and groupinfo.groupid=";


    //deletion queries

    //course
    String DELETE_FROM = "DELETE FROM"+course_table_name+" WHERE";

    //student
    String DELETE_FROM_STUDNET="DELETE FROM"+student_table_name+" WHERE";

    //group
    String DELETE_FROM_GROUP = "DELETE FROM"+groupinfo_table_name+" WHERE";

    //groupmember
    String DELETE_FROM_GROUPMEMBER = "DELETE FROM "+group_member+" WHERE groupid =";// and studentid = ?

    //updation queries

    //student
    String UPDATE_STUDENT="UPDATE"+student_table_name+"SET ";

    //single select

    //group

    String SELECT_ONE = "SELECT * FROM"+groupinfo_table_name+"WHERE groupid = ";

    //select phone numbers
    String SELECT_PHONE_NUMBER = "SELECT studentphone from"+student_table_name+" WHERE studentid = ";

    //select course name
    String SELECT_COURSE_NAME = "SELECT coursename from "+course_table_name+" WHERE courseid = ";


    /**
     *  given below are the queries intended only for development purpose .
     *
     */

    @Deprecated
    String DROP_TABLE="DROP TABLE";
}
