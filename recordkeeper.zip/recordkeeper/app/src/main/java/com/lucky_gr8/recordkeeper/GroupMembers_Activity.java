package com.lucky_gr8.recordkeeper;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class GroupMembers_Activity extends AppCompatActivity {

    private FloatingActionButton fab_add , fab_sms ;
    private static final String TAG = "GroupMembers_Activitylog";
    private TextView groupname , description , others;
    private LinkedList<Object> all_records;
    private Dialog addstudnetdialog;
    private Context thiscontext;
    private int this_groupid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_members_);
        thiscontext=this;


        groupname = findViewById(R.id.groupmembernav_textfield_groupname);
        description = findViewById(R.id.groupmembernav_textfield_groupdescription);
        others = findViewById(R.id.groupmembernav_textfield_group_date_active);
        all_records = new LinkedList<>();

        fab_add = findViewById(R.id.FAB_addgroupmembers);
        fab_sms = findViewById(R.id.FAB_sendSMS);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int groupid = extras.getInt("groupid");
            Log.d(TAG, "onCreate: " + groupid);

            DB_configrator db_configrator = new DB_configrator(this);
            db_configrator.create_table(2);
            Groupinfo_DTO record = (Groupinfo_DTO) db_configrator.select_one(groupid,2);

            Log.d(TAG, "onCreate: "+record.toString());
            this_groupid=record.getGroupid();
            groupname.setText(record.getGroupname());
            description.setText(record.getGroupdescription());

            String str;
            str = "started :: "+Long.toString(record.getStartdate());
            if(record.getIsactive()==1)
                str+=" active :: true";
            else
                str+=" active :: false";

            others.setText(str);

            db_configrator.close_db();
        }

        addstudnetdialog = new Dialog(this);




        //recycler code

        DB_configrator db_configrator = new DB_configrator(this);
        if(db_configrator.create_table(4)){
            all_records = db_configrator.select_all_from_groupmember(this_groupid);
            if(all_records!=null){

                db_configrator.close_db();

                RecyclerView recycleV = findViewById(R.id.recycler_groupmembers);
                recycleV.setLayoutManager(new LinearLayoutManager(this));
                recycleV.setAdapter(new RecyclerAdapter_GroupMember(this,all_records,fab_sms));
            }
        }else{
            Log.d(TAG, "onCreate: error occured");
        }

        //permission check code



    }


    @SuppressLint("RestrictedApi")
    public void unclockmoreoptions(View view) {

        if(fab_add.getVisibility()==View.INVISIBLE)
        {
            fab_add.setVisibility(View.VISIBLE);
            fab_sms.setVisibility(View.VISIBLE);

            view.animate().alpha(0.5f);
        }
        else{
            fab_add.setVisibility(View.INVISIBLE);
            fab_sms.setVisibility(View.INVISIBLE);

            view.animate().alpha(1);
        }
    }

    @SuppressLint("RestrictedApi")
    public void showaddstudentpopup(View view) {
        fab_add.setVisibility(View.INVISIBLE);
        fab_sms.setVisibility(View.INVISIBLE);
        findViewById(R.id.FAB_openoptions).animate().alpha(1);
        

        addstudnetdialog.setContentView(R.layout.student_listshow_popup);

        RecyclerView recyclerView = addstudnetdialog.findViewById(R.id.recycler_showstudents);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        DB_configrator db_configrator = new DB_configrator(this);

        boolean result = db_configrator.create_table(1);

        if (result) {
            all_records = db_configrator.select_all(1);
            if (all_records != null) {
                Log.d(TAG, "onCreate: records were recieved");
                for (int i = 0; i < all_records.size(); i++) {
                    Student_DTO rec = (Student_DTO) all_records.get(i);
                    Log.d(TAG, "onCreate: " + rec.toString());
                }

                GroupMember_Add_Popup_Adapter recycleradapter = new GroupMember_Add_Popup_Adapter(this,all_records,addstudnetdialog,this_groupid);
                recyclerView.setAdapter(recycleradapter);
                db_configrator.close_db();
            } else
                Log.d(TAG, "onCreate: records were not recieved");
        } else
            Log.d(TAG, "onCreate: table was not created");

        addstudnetdialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        addstudnetdialog.show();

        addstudnetdialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                //Toast.makeText(thiscontext, "dialog closed", Toast.LENGTH_SHORT).show();
                DB_configrator db_configrator = new DB_configrator(thiscontext);
                if(db_configrator.create_table(4)){
                    all_records = db_configrator.select_all_from_groupmember(this_groupid);
                    if(all_records!=null){

                        db_configrator.close_db();

                        RecyclerView recycleV = findViewById(R.id.recycler_groupmembers);

                        recycleV.setLayoutManager(new LinearLayoutManager(thiscontext));
                        recycleV.setAdapter(new RecyclerAdapter_GroupMember(thiscontext,all_records,fab_sms));
                    }
                }else{
                    Log.d(TAG, "onCreate: error occured");
                }
            }
        });

    }

}
