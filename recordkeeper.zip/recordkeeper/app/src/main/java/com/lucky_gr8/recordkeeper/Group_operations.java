package com.lucky_gr8.recordkeeper;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.design.button.MaterialButton;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class Group_operations extends AppCompatActivity {
    private static final String TAG = "Group_operationslog";
    private Dialog dialog;
    private LinkedList<Object> records;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_operations);
        dialog = new Dialog(this);

        records= new LinkedList<>();

        DB_configrator db_configrator = new DB_configrator(this);
        boolean result = db_configrator.create_table(2);
        if(result)
        records=db_configrator.select_all(2);

        if(records!=null){
            db_configrator.close_db();

            RecyclerView recycleV = findViewById(R.id.Recycler_group);
            recycleV.setLayoutManager(new LinearLayoutManager(this));
            recycleV.setAdapter(new RecyclerAdapter_group(this,records,Group_operations.this));
        }
    }
    
    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed: ");
        finish();
        Intent openMainActivity= new Intent(this, MainActivity.class);
        openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openMainActivity, 0);
    }

    public void add_group(final View view) {
        dialog.setContentView(R.layout.group_add_popup);
        ImageView close_popup = dialog.findViewById(R.id.close_popup_group);

        final TextInputEditText textInputEditText_name = dialog.findViewById(R.id.TextField_popup_groupname);
        final EditText editText_groupdescription  = dialog.findViewById(R.id.TextField_popup_groupdescription);
        final Spinner spinner_courses = dialog.findViewById(R.id.course_popup_spinner_group);
        List<Course_DTO> categories = new LinkedList<>();
        Course_DTO rec;
        DB_configrator db_configrator = new DB_configrator(this);
        boolean result = db_configrator.create_table(3);
        List<Object> courses = db_configrator.select_all(3);
        if(courses!=null){
            categories.add(new Course_DTO("select a course", 0));
            for (int i = 0; i < courses.size(); i++) {
                rec = (Course_DTO) courses.get(i);
                categories.add(rec);
            }
        }
        db_configrator.close_db();
        ArrayAdapter<Course_DTO> dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_courses.setAdapter(dataAdapter);

        close_popup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        MaterialButton materialButton_confirm = dialog.findViewById(R.id.popup_confirm_button_group);
        materialButton_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean valid=true;

                String groupname = textInputEditText_name.getText().toString().trim();
                String groupdescription = editText_groupdescription.getText().toString().trim();
                int selected_index = spinner_courses.getSelectedItemPosition();

                if(groupname.isEmpty() || selected_index==0)
                    valid=false;

                if(valid){

                    if(groupdescription.isEmpty())
                        groupdescription="no description";
                    
                   Course_DTO course = (Course_DTO) spinner_courses.getSelectedItem();
                   Groupinfo_DTO record = new Groupinfo_DTO(groupname,groupdescription,course.getCourseid(),1);

                    /*SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String currentDateandTime = sdf.format(new Date());
                    Log.d(TAG, "onClick: "+currentDateandTime);*/
                   
                   DB_configrator db_configrator = new DB_configrator(getApplicationContext());
                   boolean resut = db_configrator.create_table(2);
                   if(resut){
                       resut=db_configrator.insert_into_table(record,2);
                       if(resut){
                           Log.d(TAG, "onClick: record inserted");

                           records=db_configrator.select_all(2);

                           if(records!=null){
                               db_configrator.close_db();

                               RecyclerView recycleV = findViewById(R.id.Recycler_group);
                               recycleV.setLayoutManager(new LinearLayoutManager(Group_operations.this));
                               recycleV.setAdapter(new RecyclerAdapter_group(getApplicationContext(),records,Group_operations.this));
                           }


                           db_configrator.close_db();
                           dialog.dismiss();
                           Snackbar.make(getCurrentFocus(), "record was inserted", Snackbar.LENGTH_LONG)
                                   .setAction("okay", new View.OnClickListener() {
                                       @Override
                                       public void onClick(View view) {

                                       }
                                   })
                                   .setActionTextColor(getCurrentFocus().getResources().getColor(android.R.color.holo_red_light))
                                   .show();
                       }
                       else
                           Log.d(TAG, "onClick: did not insert");
                   }else{
                       Log.d(TAG, "onClick: table was not created");
                   }

                }else
                {
                    Vibrator vibrator = (Vibrator) getApplicationContext().getSystemService(getApplication().VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(300);
                    }
                    Snackbar.make(getCurrentFocus(), "you need to select all inputs", Snackbar.LENGTH_LONG)
                            .setAction("CLOSE", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                }
                            })
                            .setActionTextColor(getCurrentFocus().getResources().getColor(android.R.color.holo_red_light))
                            .show();
                }
            }
        });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();


    }
}
