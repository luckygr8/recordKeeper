package com.lucky_gr8.recordkeeper;

import java.util.Objects;

public class GroupMember_DTO {

    private int groupid;
    private int studentid;
    private String studentename;
    private int isactive;


    public GroupMember_DTO(int groupid, int studentid) {
        this.groupid = groupid;
        this.studentid = studentid;
    }

    public GroupMember_DTO() {
    }

    public GroupMember_DTO(int groupid, int studentid, String studentename, int isactive) {
        this.groupid = groupid;
        this.studentid = studentid;
        this.studentename = studentename;
        this.isactive = isactive;
    }

    public int getGroupid() {
        return groupid;
    }

    public void setGroupid(int groupid) {
        this.groupid = groupid;
    }

    public int getStudentid() {
        return studentid;
    }

    public void setStudentid(int studentid) {
        this.studentid = studentid;
    }

    public String getStudentename() {
        return studentename;
    }

    public void setStudentename(String studentename) {
        this.studentename = studentename;
    }

    public int getIsactive() {
        return isactive;
    }

    public void setIsactive(int isactive) {
        this.isactive = isactive;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupMember_DTO that = (GroupMember_DTO) o;
        return groupid == that.groupid &&
                studentid == that.studentid &&
                isactive == that.isactive &&
                Objects.equals(studentename, that.studentename);
    }

    @Override
    public int hashCode() {
        return Objects.hash(groupid, studentid, studentename, isactive);
    }

    @Override
    public String toString() {
        return "GroupMember_DTO{" +
                "groupid=" + groupid +
                ", studentid=" + studentid +
                ", studentename='" + studentename + '\'' +
                ", isactive=" + isactive +
                '}';
    }
}
