package com.lucky_gr8.recordkeeper;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.LinkedList;
import java.util.List;

import static android.content.Context.INPUT_METHOD_SERVICE;

public class Student_AddFragment extends Fragment{

    private List<Object> courses;
    private List<Course_DTO> categories;
    private DB_configrator db_configrator;
    private Spinner course_spinner;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.student_add_fragment, container, false);

        course_spinner = view.findViewById(R.id.course_spinner);

       course_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

           }

           @Override
           public void onNothingSelected(AdapterView<?> parent) {

           }
       });
        categories = new LinkedList<>();
        Course_DTO rec;
        db_configrator = new DB_configrator(getContext());
        boolean result = db_configrator.create_table(3);
        if(result){
            courses = db_configrator.select_all(3);
            if(courses!=null)
            {
                categories.add(new Course_DTO("select a course",0));
                if(courses.size()>0)
                    for(int i=0;i<courses.size();i++){
                        rec = (Course_DTO)courses.get(i);
                        categories.add(rec);
                    }
            }
        }

        ArrayAdapter<Course_DTO> dataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, categories);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        course_spinner.setAdapter(dataAdapter);
        return view;
    }

}
