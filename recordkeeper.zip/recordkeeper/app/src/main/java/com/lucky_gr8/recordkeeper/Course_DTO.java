package com.lucky_gr8.recordkeeper;

import java.util.Objects;

public class Course_DTO {
    private int courseid;
    private String coursename;

    public Course_DTO(String coursename) {
        this.coursename = coursename;
    }
    public Course_DTO(String coursename , int courseid) {
        this.coursename = coursename;
        this.courseid=courseid;
    }
    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course_DTO that = (Course_DTO) o;
        return courseid == that.courseid &&
                Objects.equals(coursename, that.coursename);
    }

    @Override
    public int hashCode() {
        return Objects.hash(courseid, coursename);
    }

    @Override
    public String toString() {
        if(courseid!=0)
        return coursename.toUpperCase() + " [ "+courseid+" ]";
        else
            return coursename.toUpperCase();
    }
}
