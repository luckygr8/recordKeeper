package com.lucky_gr8.recordkeeper;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.design.button.MaterialButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.LinkedList;

public class GroupMember_Add_Popup_Adapter extends RecyclerView.Adapter<GroupMember_Add_Popup_Adapter.ViewHolder> {

    private static final String TAG = "GroupMember_Add_Popup_Alog";
    private Context context;
    private LinkedList<Object> all_records;
    private Student_DTO curr_rec = new Student_DTO();
    private int itemposition;
    private LinkedList<GroupMember_Add_Popup_Adapter.ViewHolder> selected_views = new LinkedList<>();
    private int selected_item_count = 0;
    private Dialog addstudnetdialog;
    private final int groupid;

    public GroupMember_Add_Popup_Adapter(Context context, LinkedList<Object> all_records, Dialog addstudnetdialog, final int groupid) {
        this.context = context;
        this.all_records = all_records;
        this.addstudnetdialog = addstudnetdialog;
        this.groupid = groupid;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = LayoutInflater.from(viewGroup.getContext());
        View v = li.inflate(R.layout.student_listshow_popup_recycler_item, viewGroup, false);
        return new GroupMember_Add_Popup_Adapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        curr_rec = (Student_DTO) all_records.get(i);
        String str = curr_rec.getStudentphone() + "\n";
        if (curr_rec.getIsactive() == 1)
            str += " active";
        else
            str += " non-active";
        viewHolder.Tview_select_student.setText(curr_rec.getStudentname());

        //viewHolder.groupmember_item_textV_information.setText(str);

        viewHolder.rec.setStudentname(curr_rec.getStudentname());
        viewHolder.rec.setStudentphone(curr_rec.getStudentphone());
        viewHolder.rec.setCourseid(curr_rec.getCourseid());
        viewHolder.rec.setStudentid(curr_rec.getStudentid());
        viewHolder.rec.setIsactive(curr_rec.getIsactive());
        viewHolder.rec.setStudentid(curr_rec.getStudentid());

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!viewHolder.is_selected) {
                    selected_item_count++;
                    viewHolder.ImgView_select_student.setVisibility(View.VISIBLE);
                    int backgroundColor = ContextCompat.getColor(context, R.color.dark);
                    v.setBackgroundColor(backgroundColor);
                    viewHolder.is_selected = true;
                    selected_views.add(viewHolder);

                    Log.d(TAG, "onClick: "+selected_item_count);
                } else {
                    selected_item_count--;
                    viewHolder.ImgView_select_student.setVisibility(View.INVISIBLE);
                    int backgroundColor = ContextCompat.getColor(context, R.color.colorPrimaryDark);
                    v.setBackgroundColor(backgroundColor);
                    viewHolder.is_selected = false;
                    selected_views.remove(viewHolder);

                    Log.d(TAG, "onClick: "+selected_item_count);
                }
            }
        });

        MaterialButton popup_showstudents_confirm_button = addstudnetdialog.findViewById(R.id.popup_showstudents_confirm_button);
        popup_showstudents_confirm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DB_configrator db_configrator = new DB_configrator(context);
                boolean result = db_configrator.create_table(4) , flag=true;
                if (result) {

                    for (int i = 0; i < selected_views.size(); i++) {
                        ViewHolder rec = selected_views.get(i);
                        Student_DTO student = rec.rec;
                        Log.d(TAG, "onClick: studentid" + student.getStudentid() + " groupid :: " + groupid);
                        
                        GroupMember_DTO record = new GroupMember_DTO(groupid,student.getStudentid());
                        result = db_configrator.insert_into_table(record,4);
                        if(result){
                            Log.d(TAG, "onClick: record was inserted");
                            flag=true;
                        }
                        else{
                            Snackbar.make(v, "an error has occured", Snackbar.LENGTH_LONG)
                                    .setAction("CLOSE", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {

                                        }
                                    })
                                    .setActionTextColor(v.getResources().getColor(android.R.color.holo_red_light))
                                    .show();
                            Log.d(TAG, "onClick: failed to insert");
                            flag=false;
                        }
                    }
                    if(flag){
                        if(selected_item_count>0)
                        Snackbar.make(v, "students were added", Snackbar.LENGTH_LONG)
                                .setAction("CLOSE", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                    }
                                })
                                .setActionTextColor(v.getResources().getColor(android.R.color.holo_red_light))
                                .show();

                        addstudnetdialog.dismiss();
                    }
                } else {
                    Snackbar.make(v, "failure", Snackbar.LENGTH_LONG)
                            .setAction("CLOSE", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                }
                            })
                            .setActionTextColor(v.getResources().getColor(android.R.color.holo_red_light))
                            .show();
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return all_records.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView Tview_select_student;
        ImageView ImgView_select_student;
        boolean is_selected;
        Student_DTO rec;
        int corresponding_item_psition;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            is_selected = false;
            Tview_select_student = itemView.findViewById(R.id.Tview_select_student);
            ImgView_select_student = itemView.findViewById(R.id.ImgView_select_student);
            rec = new Student_DTO();
            corresponding_item_psition = 0;
        }
    }
}
