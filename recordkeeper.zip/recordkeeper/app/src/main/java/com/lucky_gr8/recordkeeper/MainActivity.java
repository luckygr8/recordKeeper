package com.lucky_gr8.recordkeeper;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivitylog";
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private NavigationView mnav;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DB_configrator db_configrator = new DB_configrator(this);
        db_configrator.create_table(1);
        db_configrator.create_table(2);
        db_configrator.create_table(3);
        db_configrator.create_table(4);

        db_configrator.close_db();

        //setting up the custom toolbar
        setToolBar();

        //navbar onclick listeners
        mnav = findViewById(R.id.menuDrawer_home);
        mnav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                finish();
                switch (menuItem.getItemId()) {
                    case R.id.menu_student:

                        intent = new Intent(getApplicationContext(), Student_operations.class);
                        startActivity(intent);
                        break;
                    case R.id.menu_group:

                        intent = new Intent(getApplicationContext(), Group_operations.class);
                        startActivity(intent);
                        break;
                    case R.id.menu_course:

                        intent = new Intent(getApplicationContext(), Course_operations.class);
                        startActivity(intent);
                        break;
                }
                return false;
            }
        });

    }

    private void setToolBar() {
        drawerLayout = findViewById(R.id.nav_drawer);

        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        ActionBarDrawerToggle abdt = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name);

        drawerLayout.addDrawerListener(abdt);

        abdt.syncState();

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: main resumed");

    }
}
