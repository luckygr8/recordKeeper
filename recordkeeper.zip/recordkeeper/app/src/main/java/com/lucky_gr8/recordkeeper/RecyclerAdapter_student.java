package com.lucky_gr8.recordkeeper;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.design.button.MaterialButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class RecyclerAdapter_student extends RecyclerView.Adapter<RecyclerAdapter_student.Viewholder> {

    private static final String TAG = "RecyclerAdprstudntlog";
    private Context context;
    private LinkedList<Object> all_records;
    private Student_DTO curr_rec = new Student_DTO();
    private int itemposition;
    View view;
    //private LinkedList<Object> records_to_be_deleted = new LinkedList<>();
    private LinkedList<Viewholder> selected_views = new LinkedList<>();
    private int selected_item_count = 0;
    private Viewholder view_to_be_updated = null;
    private Dialog dialog;

    public RecyclerAdapter_student(Context context, LinkedList<Object> all_records, View view) {
        this.context = context;
        this.all_records = all_records;
        this.view = view;
    }

    public void showsnackbar() {
        if (selected_item_count == 0) {
            Snackbar.make(view, "no record selected", Snackbar.LENGTH_LONG)
                    .setAction("CLOSE", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                        }
                    })
                    .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                    .show();
        } else {

            Snackbar.make(view, "selected records : " + selected_item_count, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.delete_string, new View.OnClickListener() {

                        @Override
                        public void onClick(final View view) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            builder.setMessage(selected_item_count+" record(s) will be permanently deleted ")
                                    .setCancelable(false)
                                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            int total = selected_views.size();
                                            DB_configrator db_configrator = new DB_configrator(context);
                                            boolean result = db_configrator.create_table(1);
                                            Viewholder viewholder;
                                            if (result) {
                                                for (int i = 0; i < total; i++) {
                                                    viewholder = selected_views.get(i);
                                                    curr_rec = viewholder.rec;
                                                    Log.d(TAG, "onClick: " + curr_rec.toString());
                                                    result = db_configrator.delete_from_database(curr_rec, 1);
                                                    if (result) {
                                                        Log.d(TAG, "onClick: record with id :: " + curr_rec.getStudentid() + " name:: " + curr_rec.getStudentname() + " was deleted");
                                                        all_records.remove(curr_rec);
                                                        notifyItemRemoved(viewholder.corresponding_item_psition);

                                                    } else{
                                                        Log.d(TAG, "onClick: delete failure");
                                                    Toast.makeText(context, "this record is in some group , cant be deleted", Toast.LENGTH_SHORT).show();}
                                                }
                                            }
                                            db_configrator.close_db();
                                        }
                                    })
                                    .setNeutralButton("cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                        }
                            });
                            AlertDialog alert = builder.create();

                            alert.setTitle("student operations");

                            alert.show();
                        }
                    })
                    .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                    .show();
        }
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = LayoutInflater.from(viewGroup.getContext());
        View v = li.inflate(R.layout.recycler_student_item, viewGroup, false);
        return new Viewholder(v);
    }

    public void showpopup() {
        dialog.setContentView(R.layout.student_update_popup_dialog);
        ImageView close_popup = dialog.findViewById(R.id.close_popup);

        final TextInputEditText TextInputLayout_popup_studentname = dialog.findViewById(R.id.TextField_popup_studentname);
        final TextInputEditText TextInputLayout_popup_studentphone = dialog.findViewById(R.id.TextField_popup_studentphone);
        final CheckBox isactive_checkbox = dialog.findViewById(R.id.student_popup_checkbox);
        MaterialButton popup_confirm_button = dialog.findViewById(R.id.popup_confirm_button);

        final Spinner course_spinner = dialog.findViewById(R.id.course_popup_spinner);
        List<Course_DTO> categories = new LinkedList<>();
        Course_DTO rec;
        final DB_configrator db_configrator = new DB_configrator(context);
        List<Object> courses = db_configrator.select_all(3);
        categories.add(new Course_DTO("select a course", 0));
        for (int i = 0; i < courses.size(); i++) {
            rec = (Course_DTO) courses.get(i);
            categories.add(rec);
        }
        db_configrator.close_db();
        ArrayAdapter<Course_DTO> dataAdapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, categories);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        course_spinner.setAdapter(dataAdapter);

        close_popup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        popup_confirm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean valid = true;
                String updated_student_name = TextInputLayout_popup_studentname.getText().toString().trim();
                String updated_student_phone = TextInputLayout_popup_studentphone.getText().toString().trim();
                int isactive;
                if (isactive_checkbox.isChecked()) isactive = 1;
                else isactive = 0;
                int index = course_spinner.getSelectedItemPosition();
                if (updated_student_name.isEmpty() || updated_student_phone.isEmpty() || index == 0)
                    valid = false;

                if (valid) {
                    DB_configrator db_configrator = new DB_configrator(context);

                    Course_DTO course = (Course_DTO) course_spinner.getSelectedItem();

                    Student_DTO rec = new Student_DTO(view_to_be_updated.rec.getStudentid(), updated_student_name, updated_student_phone, course.getCourseid(), isactive);
                    boolean result = db_configrator.update_into_database(rec, 1);

                    if (result) {
                        Log.d(TAG, "onClick: record was updated");
                        all_records.set(view_to_be_updated.corresponding_item_psition, rec);
                        notifyItemChanged(view_to_be_updated.corresponding_item_psition);
                        Snackbar.make(view, "update complete", Snackbar.LENGTH_LONG)
                                .setAction("CLOSE", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                    }
                                })
                                .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                                .show();
                        dialog.dismiss();
                    } else
                        Log.d(TAG, "onClick: record was not updated");
                } else {
                    Vibrator vibrator = (Vibrator) context.getSystemService(context.VIBRATOR_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(300);
                    }
                }
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder viewholder, int i) {
        curr_rec = (Student_DTO) all_records.get(i);
        String str = curr_rec.getStudentname() + "\n" + curr_rec.getStudentphone();
        viewholder.student_item_textV.setText(str);

        DB_configrator db_configrator = new DB_configrator(context);
        String coursename = db_configrator.select_coursename(curr_rec.getCourseid());
        if(coursename!=null)
            viewholder.student_item_textVcourse.setText(coursename);

        db_configrator.close_db();

        dialog = new Dialog(context);


        viewholder.rec.setStudentname(curr_rec.getStudentname());
        viewholder.rec.setStudentphone(curr_rec.getStudentphone());
        viewholder.rec.setCourseid(curr_rec.getCourseid());
        viewholder.rec.setStudentid(curr_rec.getStudentid());
        viewholder.rec.setIsactive(curr_rec.getIsactive());
        viewholder.rec.setStudentid(curr_rec.getStudentid());

        Log.d(TAG, "onBindViewHolder: " + viewholder.rec.toString());


        viewholder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (selected_item_count == 0 && !viewholder.is_selected) {
                    selected_item_count++;
                    viewholder.is_selected = true;
                    viewholder.student_item_checked.setVisibility(View.VISIBLE);
                    selected_views.add(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                    v.setBackgroundColor(backgroundColor);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;
                    viewholder.student_item_update.setVisibility(View.VISIBLE);
                    view_to_be_updated = viewholder;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar();

                }
                return true;
            }
        });
        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selected_item_count > 0 && !viewholder.is_selected) {
                    viewholder.is_selected = true;
                    selected_item_count++;
                    viewholder.student_item_checked.setVisibility(View.VISIBLE);
                    selected_views.add(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.onlongclick);
                    v.setBackgroundColor(backgroundColor);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;


                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar();

                    return;
                }
                if (viewholder.is_selected) {
                    selected_item_count--;
                    viewholder.is_selected = false;
                    selected_views.remove(viewholder);
                    int backgroundColor = ContextCompat.getColor(context, R.color.default_color);
                    v.setBackgroundColor(backgroundColor);
                    viewholder.student_item_checked.setVisibility(View.INVISIBLE);
                    itemposition = viewholder.getAdapterPosition();
                    viewholder.corresponding_item_psition = itemposition;
                    viewholder.student_item_update.setVisibility(View.INVISIBLE);

                    Log.d(TAG, "onLongClick: itemposition:: " + itemposition);
                    Log.d(TAG, "onLongClick: selected item count:: " + selected_item_count);
                    showsnackbar();

                    return;
                }
            }
        });

        viewholder.student_item_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selected_views.size() == 1) {

                    Log.d(TAG, "onClick: update :: " + viewholder.rec.toString());
                    //DB_configrator db_configrator = new DB_configrator(context);
                    //curr_rec = viewholder.rec;
                    //db_configrator.update_into_database(curr_rec,1);
                    curr_rec = viewholder.rec;
                    view_to_be_updated = viewholder;
                    showpopup();

                } else
                    Snackbar.make(view, "can not update muptiple records", Snackbar.LENGTH_LONG)
                            .setAction("CLOSE", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                }
                            })
                            .setActionTextColor(view.getResources().getColor(android.R.color.holo_red_light))
                            .show();
            }
        });

    }


    @Override
    public int getItemCount() {
        return all_records.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {

        TextView student_item_textV , student_item_textVcourse;
        ImageView student_item_update;
        ImageView student_item_checked;
        boolean is_selected;
        Student_DTO rec;
        int corresponding_item_psition;

        public Viewholder(@NonNull View itemView) {

            super(itemView);

            is_selected = false;
            student_item_textV = itemView.findViewById(R.id.student_item_textV);
            student_item_textVcourse = itemView.findViewById(R.id.student_item_textVcourse);
            student_item_checked = itemView.findViewById(R.id.student_item_checked);
            student_item_update = itemView.findViewById(R.id.student_item_update);
            rec = new Student_DTO();
            corresponding_item_psition = 0;
        }
    }
}
