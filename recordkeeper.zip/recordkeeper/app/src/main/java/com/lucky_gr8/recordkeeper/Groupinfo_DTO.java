package com.lucky_gr8.recordkeeper;

import java.util.Objects;

public class Groupinfo_DTO {
    private String groupname;
    private String groupdescription;
    private int groupid;
    private long startdate;
    private int courseid;
    private int isactive;

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getGroupdescription() {
        return groupdescription;
    }

    public void setGroupdescription(String groupdescription) {
        this.groupdescription = groupdescription;
    }

    public int getGroupid() {
        return groupid;
    }

    public void setGroupid(int groupid) {
        this.groupid = groupid;
    }

    public long getStartdate() {
        return startdate;
    }

    public void setStartdate(long startdate) {
        this.startdate = startdate;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public int getIsactive() {
        return isactive;
    }

    public void setIsactive(int isactive) {
        this.isactive = isactive;
    }

    public Groupinfo_DTO(String groupname, String groupdescription, long startdate, int courseid, int isactive) {
        this.groupname = groupname;
        this.groupdescription = groupdescription;
        this.startdate = startdate;
        this.courseid = courseid;
        this.isactive = isactive;
    }

    public Groupinfo_DTO(String groupname, String groupdescription, int groupid, long startdate, int courseid, int isactive) {
        this.groupname = groupname;
        this.groupdescription = groupdescription;
        this.groupid = groupid;
        this.startdate = startdate;
        this.courseid = courseid;
        this.isactive = isactive;
    }

    public Groupinfo_DTO(String groupname, String groupdescription, int courseid, int isactive) {
        this.groupname = groupname;
        this.groupdescription = groupdescription;
        this.courseid = courseid;
        this.isactive = isactive;
    }

    public Groupinfo_DTO() {
    }

    @Override
    public String toString() {
        return "Groupinfo_DTO{" +
                "groupname='" + groupname + '\'' +
                ", groupdescription='" + groupdescription + '\'' +
                ", groupid=" + groupid +
                ", startdate=" + startdate +
                ", courseid=" + courseid +
                ", isactive=" + isactive +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Groupinfo_DTO that = (Groupinfo_DTO) o;
        return groupid == that.groupid &&
                startdate == that.startdate &&
                courseid == that.courseid &&
                isactive == that.isactive &&
                Objects.equals(groupname, that.groupname) &&
                Objects.equals(groupdescription, that.groupdescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(groupname, groupdescription, groupid, startdate, courseid, isactive);
    }
}

